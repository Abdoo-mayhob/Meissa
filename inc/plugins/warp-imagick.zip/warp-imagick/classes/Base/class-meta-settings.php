<?php
/**
 * Copyright © 2017-2022 Dragan Đurić. All rights reserved.
 *
 * @package warp-imagick
 * @license GNU General Public License Version 2.
 * @copyright © 2017-2022. All rights reserved.
 * @author Dragan Đurić
 * @link https://warp-imagick.pagespeed.club/
 *
 * This copyright notice, source files, licenses and other included
 * materials are protected by U.S. and international copyright laws.
 * You are not allowed to remove or modify this or any other
 * copyright notice contained within this software package.
 */

namespace ddur\Warp_iMagick\Base;

defined( 'ABSPATH' ) || die( -1 );

use \ddur\Warp_iMagick\Base\Plugin\v1\Lib;
use \ddur\Warp_iMagick\Base\Base_Settings;

if ( ! class_exists( __NAMESPACE__ . '\Meta_Settings' ) ) {

	/** Meta Settings Class.
	 *
	 * Class between Settings and abstract Base_Settings class.
	 */
	abstract class Meta_Settings extends Base_Settings {

		// phpcs:ignore
	# region Static Manage Plugin Functions.

		/** Plugin manage action handler
		 *
		 * @param string $action - one of activate/deactivate/uninstall.
		 */
		protected static function on_manage_plugin( $action ) {

		}

		/** Get Plugin ID */
		public static function ID() {
			return wp_parse_url( get_site_url(), PHP_URL_HOST ) . '/' . self::instance()->pageslug;
		}

		// phpcs:ignore
	# endregion

	}

}
